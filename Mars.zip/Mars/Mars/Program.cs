﻿using System;

public class MarsRover
{
    public int X { get; set; }
    public int Y { get; set; }
    public char Direction { get; set; }

    public MarsRover(int x, int y, char direction)
    {
        X = x;
        Y = y;
        Direction = direction;
    }

    public void Move(string instructions)
    {
        foreach (char instruction in instructions)
        {
            if (instruction == 'L')
            {
                TurnLeft();
            }
            else if (instruction == 'R')
            {
                TurnRight();
            }
            else if (instruction == 'M')
            {
                MoveForward();
            }
        }
    }

    private void TurnLeft()
    {
        if (Direction == 'N')
            Direction = 'W';
        else if (Direction == 'W')
            Direction = 'S';
        else if (Direction == 'S')
            Direction = 'E';
        else if (Direction == 'E')
            Direction = 'N';
    }

    private void TurnRight()
    {
        if (Direction == 'N')
            Direction = 'E';
        else if (Direction == 'E')
            Direction = 'S';
        else if (Direction == 'S')
            Direction = 'W';
        else if (Direction == 'W')
            Direction = 'N';
    }

    private void MoveForward()
    {
        if (Direction == 'N')
            Y++;
        else if (Direction == 'E')
            X++;
        else if (Direction == 'S')
            Y--;
        else if (Direction == 'W')
            X--;
    }

    public override string ToString()
    {
        return $"{X} {Y} {Direction}";
    }
}

public class Program
{
    public static void Main()
    {
        string[] plateauBounds = Console.ReadLine().Split(' ');
        int maxX = int.Parse(plateauBounds[0]);
        int maxY = int.Parse(plateauBounds[1]);

        while (true)
        {
            string roverPosition = Console.ReadLine();
            if (string.IsNullOrEmpty(roverPosition))
                break;

            string roverInstructions = Console.ReadLine();
            MarsRover rover = ParseRoverPosition(roverPosition);
            rover.Move(roverInstructions);

            // Ensure the rover stays within the plateau bounds
            rover.X = Math.Max(0, Math.Min(maxX, rover.X));
            rover.Y = Math.Max(0, Math.Min(maxY, rover.Y));

            Console.WriteLine(rover);
        }
    }

    public static MarsRover ParseRoverPosition(string roverPosition)
    {
        string[] parts = roverPosition.Split(' ');
        int x = int.Parse(parts[0]);
        int y = int.Parse(parts[1]);
        char direction = char.Parse(parts[2]);
        return new MarsRover(x, y, direction);
    }
}
